module.exports = {
  region: "us-east-1",
  tableNames: {
    products: "Products",
    taxonomy: "ProductTaxonomyAttributes",
  },
};
