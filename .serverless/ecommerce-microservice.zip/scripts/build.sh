#!/bin/bash
echo "Building the project..."
npm run build
