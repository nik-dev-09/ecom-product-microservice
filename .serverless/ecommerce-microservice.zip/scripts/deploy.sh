#!/bin/bash
echo "Deploying application to AWS..."
serverless deploy
