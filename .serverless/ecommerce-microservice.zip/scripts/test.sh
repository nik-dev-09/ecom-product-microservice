#!/bin/bash
echo "Running tests..."
npm test
